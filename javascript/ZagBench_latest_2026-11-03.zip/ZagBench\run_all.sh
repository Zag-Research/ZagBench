#!/usr/bin/env bash
# Runs every ZagBench benchmark with its default iteration counts, one at a time,
# for each language given (java python javascript ruby). Git Bash on Windows.
#
# Usage:  bash run_all.sh <translations-dir> <mnist_test.csv> <out-dir> java python javascript ruby
# Example:
#   bash run_all.sh /f/00_ALL_ZagBench_Translations /f/mnist_test.csv ./logs java python javascript ruby
#
# The CSV is copied next to each harness (the benchmarks open "mnist_test.csv"
# from the working directory). Java sources are compiled first.
T="$1"; CSV="$2"; R="$3"; shift 3
mkdir -p "$R"
BENCHES="MemoizedFibonacci Fannkuch MatrixInversion ResilientBlocks StressGC DataFrame"
for lang in "$@"; do
  case $lang in
    java)       cmd="java Harness" ;;
    python)     cmd="python harness.py" ;;
    javascript) cmd="node harness.js" ;;
    ruby)       cmd="ruby harness.rb" ;;
    *)          echo "unknown language: $lang"; continue ;;
  esac
  cd "$T/$lang" || continue
  [ -f mnist_test.csv ] || cp "$CSV" mnist_test.csv
  [ "$lang" = java ] && javac -encoding UTF-8 *.java
  for b in $BENCHES; do
    out="$R/${lang}_${b}.txt"
    start=$(date +%s)
    timeout 1800 $cmd $b > "$out" 2>&1
    rc=$?
    echo "exit=$rc wall=$(( $(date +%s) - start ))s" >> "$out"
    echo "$lang $b exit=$rc"
  done
done
