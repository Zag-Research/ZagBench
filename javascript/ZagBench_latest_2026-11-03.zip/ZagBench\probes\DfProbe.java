public class DfProbe { public static void main(String[] a) throws Exception {
  BeDataFrame d = new BeDataFrame(); boolean ok = d.innerBenchmarkLoop(500);
  java.lang.reflect.Field rf = BeDataFrame.class.getDeclaredField("rows"); rf.setAccessible(true);
  long c = 0; for (String[] r : (String[][]) rf.get(d)) for (String x : r) c += Long.parseLong(x);
  System.out.println("java       df ok=" + ok + " cols=" + d.numberOfColumns() + " rows=" + d.numberOfRows() + " cellSum=" + c);
} }
