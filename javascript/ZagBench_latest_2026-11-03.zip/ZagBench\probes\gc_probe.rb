require File.join(ARGV[0], 'be_stress_gc')
b = BeStressGC.new; c = b.send(:_benchmark, 10000)
t = b.instance_variable_get(:@tree); r = b.instance_variable_get(:@random)
puts "ruby chop=#{c} tree=#{t.all_nodes.length} rand=#{r.instance_variable_get(:@rand)}"
