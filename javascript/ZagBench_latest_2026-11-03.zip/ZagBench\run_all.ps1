# Runs every ZagBench benchmark with its default iteration counts, one at a time,
# for each language given. Windows PowerShell 5.1+ / PowerShell 7, no bash needed.
#
# Usage (from this folder):
#   .\run_all.ps1                                   # all 4 languages, CSV = .\mnist_test.csv
#   .\run_all.ps1 -Langs python,ruby                # only some languages
#   .\run_all.ps1 -Csv D:\data\mnist_test.csv -Out .\logs_today
#
# If scripts are blocked:  powershell -ExecutionPolicy Bypass -File .\run_all.ps1
param(
    [string]   $Csv   = (Join-Path $PSScriptRoot 'mnist_test.csv'),
    [string]   $Out   = (Join-Path $PSScriptRoot ('logs_' + (Get-Date -Format 'yyyy-MM-dd_HHmm'))),
    [string[]] $Langs = @('java', 'javascript', 'python', 'ruby')
)

$benches = 'MemoizedFibonacci', 'Fannkuch', 'MatrixInversion', 'ResilientBlocks', 'StressGC', 'DataFrame'
if (-not (Test-Path $Csv)) { Write-Host "mnist_test.csv not found at $Csv (use -Csv <path>)"; exit 1 }
New-Item -ItemType Directory -Force $Out | Out-Null
$Out = (Resolve-Path $Out).Path
$failed = 0

foreach ($lang in $Langs) {
    switch ($lang) {
        'java'       { $exe = 'java';   $pre = @('Harness') }
        'python'     { $exe = 'python'; $pre = @('harness.py') }
        'javascript' { $exe = 'node';   $pre = @('harness.js') }
        'ruby'       { $exe = 'ruby';   $pre = @('harness.rb') }
        default      { Write-Host "unknown language: $lang"; continue }
    }
    Push-Location (Join-Path $PSScriptRoot $lang)
    Copy-Item $Csv 'mnist_test.csv' -Force          # benchmarks open it from their own folder
    if ($lang -eq 'java') { & javac -encoding UTF-8 *.java }
    foreach ($b in $benches) {
        $log   = Join-Path $Out "${lang}_${b}.txt"
        $start = Get-Date
        & $exe @pre $b *> $log
        $rc    = $LASTEXITCODE
        $wall  = [int]((Get-Date) - $start).TotalSeconds
        Add-Content $log "exit=$rc wall=${wall}s"
        if ($rc -ne 0) { $failed++ }
        $median = (Select-String -Path $log -Pattern 'median: (\d+)us' | Select-Object -First 1).Matches.Groups[1].Value
        Write-Host ("{0,-11} {1,-18} exit={2}  median={3}us  ({4}s)" -f $lang, $b, $rc, $median, $wall)
    }
    Pop-Location
}
Write-Host "Logs: $Out   Failed: $failed"
if ($failed -gt 0) { exit 1 }
