# ZagBench — Java / Python / JavaScript / Ruby (latest, 2026-11-03)

Six ZagBench benchmarks (ported from Pharo), written the same way in four
languages:

- **No built-in libraries:** the hash map, big integers (Java), copy/search/abs
  and the statistics are hand-written. File reading and timers are the only
  library use, as harness infrastructure.
- **Identical results:** the outputs match bit-for-bit across the four languages.
- **All fixes from `REPORT.md` are included.**

## What you need

| Tool | Version tested | Check with |
|---|---|---|
| Java JDK | 21.0.1 | `java -version` and `javac -version` |
| Node.js | 18.16.0 (22 LTS also fine) | `node --version` |
| Python | 3.15.2 | `python --version` |
| Ruby | 3.3.13 | `ruby --version` |
| Data | `mnist_test.csv` (10,001 lines, 785 columns) | not included (18 MB); use your own copy |

**Put `mnist_test.csv` in this folder**, next to this README.

## Folder layout

```
ZagBench/
├─ java/  python/  javascript/  ruby/   ← the benchmarks + harness, one folder per language
├─ run_all.ps1          ← run all 24 benchmarks on Windows (PowerShell, no bash needed)
├─ run_all.sh           ← same in bash (Git Bash / macOS / Linux)
├─ probes/              ← scripts that print each language's results, to prove they match
├─ results_2026-11-03/  ← my last run's logs, for comparison
├─ .vscode/tasks.json   ← VS Code tasks
├─ .zed/tasks.json      ← Zed tasks
└─ REPORT.md            ← the bug/fix report and timings
```

## Quick start (Windows PowerShell, in VS Code, Zed or any terminal)

Open this folder in the editor (VS Code: File → Open Folder; Zed: File → Open),
then open the terminal with `` Ctrl+` ``.

**Run all 24 benchmarks and save the logs:**
```powershell
powershell -ExecutionPolicy Bypass -File .\run_all.ps1
```
- This copies the CSV into each language folder, compiles Java, and runs each
  benchmark once with its defaults.
- It prints one line per benchmark (exit code, median, seconds) and saves the
  logs to `logs_<date>_<time>\`.

Only some languages, or a CSV somewhere else:
```powershell
powershell -ExecutionPolicy Bypass -File .\run_all.ps1 -Langs python,ruby -Csv D:\data\mnist_test.csv
```

## Run one benchmark by hand

Benchmark names: `MemoizedFibonacci`, `Fannkuch`, `MatrixInversion`,
`ResilientBlocks`, `StressGC`, `DataFrame`.

Optional arguments: `<name> [num-iterations [inner-iterations]]`, both
whole numbers ≥ 1.

DataFrame needs `mnist_test.csv` **inside that language's folder**. `run_all.ps1`
copies it for you, or copy it once yourself:
```powershell
foreach ($l in 'java','python','javascript','ruby') { Copy-Item .\mnist_test.csv ".\$l\" }
```

**Java** (compile once, then run from the `java` folder):
```powershell
cd java; javac -encoding UTF-8 *.java; java Harness Fannkuch; cd ..
```
**Python:**
```powershell
cd python; python harness.py Fannkuch; cd ..
```
**JavaScript:**
```powershell
cd javascript; node harness.js Fannkuch; cd ..
```
**Ruby:**
```powershell
cd ruby; ruby harness.rb Fannkuch; cd ..
```
With custom iteration counts (e.g. 5 timed runs of Fannkuch n=10):
```powershell
cd python; python harness.py Fannkuch 5 10; cd ..
```

Output format (µs):
```
Fannkuch: n=2 mean: 5032276us stdDev: 22861us (0.5%) min: … 1stQ: … median: 5032276us 3rdQ: … max: …
```
Exit code 0 means the result was checked and is correct. A failed check, a bad
argument or a missing CSV prints a message and exits 1.

## From the editor's task menu

- **VS Code:** `Ctrl+Shift+P` → **Tasks: Run Task**. Then either:
  - pick **ZagBench: Java / Python / JavaScript / Ruby** and choose a benchmark
    from the list, or
  - pick **ZagBench: all 24 (logs)**.
- **Zed:** `Alt+Shift+T` (or the command palette → **task: spawn**). Pick
  **ZagBench: all 24 (logs)** or one language (all 6 of its benchmarks).

## bash (Git Bash, macOS, Linux)

```bash
bash run_all.sh "$PWD" "$PWD/mnist_test.csv" "$PWD/logs" java javascript python ruby
```

## Check that all four languages compute the same thing

From this folder, after copying the CSV into `python/` (see above):
```powershell
python probes\eq_probe.py "$PWD\python"
```
```powershell
python probes\gc_probe.py "$PWD\python"
```
Expected output (the same for every language):
- `invSum=1.0904031553063864`
- `fib200000 mod 1e9+7=216653165`
- `cols=785 rows=500 cellSum=12056910`
- `chop=9901 tree=34 rand=208433784`

The `.js` and `.rb` probes take the same argument (the path to their language
folder). The Java probes compile next to the `java/` sources.

## For fair timings

- **Power:** plug in the charger, set Windows to **Best performance**, and set
  **sleep to Never** while plugged in. A sleeping laptop wrecked one result last time.
- **Quiet machine:** close other apps, and ideally run from a plain terminal
  rather than inside the editor (its extensions use CPU).
- **Repeat runs:** run the suite 3–5 times and compare medians. Java and JS have
  no warm-up, so their first iterations are slow.
