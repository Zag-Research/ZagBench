import sys, os; sys.path.insert(0, sys.argv[1]); os.chdir(sys.argv[1])
from be_random import BeRandom; from be_matrix import BeMatrix; from be_memoized_fibonacci import BeMemoizedFibonacci; from be_data_frame import BeDataFrame
src = BeMatrix.with_data(BeRandom().make_invertable(10)); inv = src.invert()
s = 0.0
for i in range(1, 11):
    for j in range(1, 11): s += inv.at(i, j)
print("python     invSum=%.17g identity=%s" % (s, inv.multiply(src).is_identity_matrix()))
f = BeMemoizedFibonacci(); print("python     fib200000 mod 1e9+7=%d fib10=%d" % (f.fib_memo(200000) % 1000000007, f.fib_memo(10)))
d = BeDataFrame(); ok = d.inner_benchmark_loop(500)
print("python     df ok=%s cols=%d rows=%d cellSum=%d" % (ok, d.number_of_columns(), d.number_of_rows(), sum(int(x) for r in d._rows for x in r)))
