# ZagBench rerun with Python 3.15.2 — status and bug report (2026-11-03)

> **Status:** H1, M1–M3 and L1–L4 are **fixed**; see section 6. The B items
> are about benchmark design and are not changed.

This report covers the rerun after Python 3.15.2 was installed. The setup, the
no-library rules and the earlier stages are in `BENCHMARK_REPORT.md`.

## 1. How it was run

| Item | Value |
|---|---|
| Machine | ASUS VivoBook X513EA, Intel i7-1165G7 @ 2.80 GHz (4 cores / 8 threads), 11.7 GB RAM |
| OS | Windows 11 Home 10.0.26300, **native, no VM** (`HypervisorPresent = False`) |
| Shell | Git Bash |
| Java / Node / Ruby | Oracle JDK 21.0.1 / Node v18.16.0 / Ruby 3.3.13 (no YJIT) |
| **Python** | **CPython 3.15.2** (`C:\Users\maish\AppData\Local\Python\pythoncore-3.15-64`) |
| Command | `bash run_all.sh /f/00_ALL_ZagBench_Translations /f/mnist_test.csv ./raw_logs_stage4_python315 java javascript python ruby` |
| Iterations | Each benchmark's defaults, one benchmark at a time, a fresh instance per timed iteration, no warm-up |

Logs: `raw_logs_stage4_python315/<language>_<benchmark>.txt`.

## 2. What works

### All 24 benchmarks pass (exit 0, self-check passed)

| Benchmark | Java | JavaScript | Python 3.15 | Ruby |
|---|---|---|---|---|
| MemoizedFibonacci | ✅ | ✅ | ✅ | ✅ |
| Fannkuch | ✅ | ✅ | ✅ | ✅ |
| MatrixInversion | ✅ | ✅ | ✅ | ✅ |
| ResilientBlocks | ✅ | ✅ | ✅ | ✅ |
| StressGC | ✅ | ✅ | ✅ | ✅ |
| DataFrame | ✅ | ✅ | ✅ | ✅ |

### Python 3.15 gives bit-identical results to the other languages

```
python  invSum=1.0904031553063864  identity=True
python  fib200000 mod 1e9+7=216653165  fib10=55
python  df ok=True cols=785 rows=500 cellSum=12056910
python  chop=9901 tree=34 rand=208433784
```

These match Java, JavaScript and Ruby exactly. Running with `python -W error -X dev`
produced **no warnings or deprecations** on 3.15.

### Median times (µs) and spread

| Benchmark | Java | JavaScript | Python 3.15 | Ruby |
|---|---|---|---|---|
| MemoizedFibonacci | **854,586** (5.3%) | 1,501,439 (12.6%) | 1,242,342 (12.4%) | 1,767,571 (10.2%) |
| Fannkuch | **218,288** (8.3%) | 274,579 (0.7%) | 5,757,917 (1.4%) | 9,288,836 (5.0%) |
| MatrixInversion | 2,642 (30.3%) | **1,641** (125.6%) | 48,204 (1.4%) | 71,767 (2.6%) |
| ResilientBlocks | **11,186** (18.9%) | 21,710 (14.3%) | 364,579 (3.5%) | 541,027 (2.5%) |
| StressGC | **10,466** (40.0%) | 16,988 (34.7%) | 151,485 (2.7%) | 165,247 (8.7%) |
| DataFrame | 18,651 (73.7%) | **18,240** (29.2%) | 148,788 (1.1%) | 539,338 (5.2%) |

The percentage is stdDev as a share of the mean. Java and JS spread is high
because the first iterations run before the JIT has compiled the code (see B1).

### Python 3.10 → 3.15

| Benchmark | 3.10.11 | 3.15.2 | Change |
|---|---|---|---|
| MemoizedFibonacci | 948,336 | 1,242,342 | **31% slower** |
| Fannkuch | 10,705,670 | 5,757,917 | 1.86× faster |
| MatrixInversion | 74,394 | 48,204 | 1.54× faster |
| ResilientBlocks | 666,987 | 364,579 | 1.83× faster |
| StressGC | 316,330 | 151,485 | 2.09× faster |
| DataFrame | 270,639 | 148,788 | 1.82× faster |

Python 3.15 is now faster than Ruby on 5 of 6 benchmarks; StressGC is a near
tie. Fibonacci got slower because almost all of its time is spent allocating
and adding big integers (see B3), and run-to-run noise on this laptop is large
(see B2).

## 3. Bugs and code errors

Severity: **High** gives wrong or misleading numbers, **Medium** crashes or
gives silent garbage on bad input, **Low** is cosmetic or a robustness gap.

### H1 — The harness folder still contains the old, buggy code (High)
`F:\01_Harness_Infrastructure\01_harness\` was never updated with the fixes
that went into `F:\00_ALL_ZagBench_Translations\`. These files differ:

| Language | Out-of-date files in `01_harness` |
|---|---|
| Java | `BeFannkuch.java` (**wrong checksum**: lexicographic order, fails verification), `BeMemoizedFibonacci.java` (`java.math.BigInteger` + `HashMap`), `BeDataFrame.java`, `BeMatrix.java`, `BeRandomTreeNode.java`, `Run.java` (`System.arraycopy`) |
| Python | `run.py`, `be_random.py` (library helpers) |
| JavaScript | `run.js`, `be_random.js` (`slice`, `Math.min/max/abs`) |
| Ruby | `run.rb`, `be_random.rb` (`dup`, `minmax`, `sum`) |

If benchmarks are run from that folder, Java Fannkuch fails and the
no-library rule is broken.
**Fix:** copy these files from the translations folder into `01_harness`, or
keep only one copy of the code.

### M1 — Quartiles print 0 when there is only one iteration (Medium, all 4 languages)
With `n=1` the output shows `1stQ: 0us … 3rdQ: 0us`. For example:
```
StressGC: n=1 mean: 2908us stdDev: 0us (0.0%) min: 2908us 1stQ: 0us median: 2908us 3rdQ: 0us max: 2908us
```
`q1 = medianOf(s, 0, n/2)` takes an empty range when n=1, and the empty range
returns 0. Where it happens:
- `python/run.py:65`
- `javascript/run.js:53`
- `ruby/run.rb:55`
- `java/Run.java:128`

With n=2 (Fannkuch's default), Q1 and Q3 are just min and max.
**Fix:** when n < 2, set Q1 = median = Q3 = the single time. Or, better, give
Fannkuch more iterations (see B4).

### M2 — Zero iterations crash; JavaScript prints NaN and exits 0 instead (Medium, all 4)
`harness <Bench> 0` divides by the iteration count:

| Language | Behaviour | Location |
|---|---|---|
| Java | `ArithmeticException: / by zero`, exit 1 | `Run.java:73` |
| Python | `ZeroDivisionError`, exit 1 | `run.py:156` |
| Ruby | `ZeroDivisionError`, exit 1 | `run.rb:137` |
| JavaScript | prints `mean: NaNus … min: undefinedus` and **exits 0** | `run.js:134` |

**Fix:** in each harness, reject `num-iterations < 1` with a usage message and exit 1.

### M3 — A non-numeric argument is handled differently in each language (Medium)
`harness StressGC abc`:

| Language | Behaviour | Location |
|---|---|---|
| Java | `NumberFormatException`, exit 1 (correct) | — |
| Python | `ValueError`, exit 1 (correct) | — |
| Ruby | `"abc".to_i` silently becomes 0, which then crashes with `ZeroDivisionError` | `harness.rb:27-28` |
| JavaScript | `parseInt` gives `NaN`; prints `n=NaN mean: NaNus …` and **exits 0** | `harness.js:24-25` |

Negative counts (e.g. `-3`) are also accepted by JS and exit 0.
**Fix:** check that each argument is a positive whole number. In Ruby use
`Integer(ARGV[1])`; in JS check `Number.isInteger(n) && n > 0`.

### L1 — Two benchmarks never check their result (Low, all 4)
MemoizedFibonacci and StressGC always return `true`:
- Java: `BeMemoizedFibonacci.java:38` and `BeStressGC.java:22`
- Python: `be_memoized_fibonacci.py:43` and `be_stress_gc.py:30`
- JavaScript and Ruby: the same places in their files

This matches the Pharo original, but it means a broken port would still pass.
The external probes (`probes/`) are currently the only proof that they are correct.
**Fix (optional):** check `fib(200000) mod 1000000007 == 216653165`, and check
StressGC's `chop=9901 tree=34` at 10,000 iterations.

### L2 — Verification only works for the default inner count (Low, all 4)
- ResilientBlocks fails for any inner count other than 2500 (`No verification result`).
  The expected value is simply `n(n-1)/2`, so it can be computed for any n.
- Fannkuch fails for n > 11, because the table has no entry for it.

**Fix:** use the formula for ResilientBlocks. For Fannkuch, either accept that
only n ≤ 11 can be checked or extend the table.

### L3 — Error message when `mnist_test.csv` is missing (Low)
All four languages crash with a stack trace if the CSV isn't in the working
directory. This is expected, because `run_all.sh` copies the CSV in, but a
one-line "run from the folder containing mnist_test.csv" message would be clearer.

### L4 — Python's MemoizedFibonacci doesn't set its own iteration counts (Low)
`be_memoized_fibonacci.py` relies on the base-class defaults (10 / 250000).
Java, JS and Ruby set them explicitly. The values are the same today, but if
the base class changes, the languages would drift apart.
**Fix:** add `MAIN_ITERATIONS = 10` and `INNER_ITERATIONS = 250000` to the class.

## 4. Benchmark-design issues (not code bugs, but they affect fairness)

**B1 — No warm-up.**
- Java's and JS's first iterations include JIT compilation. That's why the
  spread reaches 30–125% on short benchmarks (MatrixInversion is ~2 ms per
  iteration; DataFrame's Java max is 65 ms while its median is 18.6 ms).
- **Rectify:** add an untimed warm-up of a few iterations, or report "median of
  the last N". Until then, compare medians, not means.

**B2 — Laptop noise is large.**
- The Java and JS code did **not change** between stage 3 and this run, yet
  their medians moved: JS ResilientBlocks went from 13.5 ms to 21.7 ms (+60%),
  and Java Fibonacci from 761 ms to 855 ms (+12%).
- Causes: turbo boost, the thermal limit, the Windows power mode and
  background apps.
- **Rectify:**
  - Plug in the charger, set Windows to "Best performance" and close other apps.
  - Run the suite 3–5 times and report the median of the medians.
  - Ideally, use a dedicated, quiet machine or VM.

**B3 — MemoizedFibonacci is mostly a memory test.**
- The cache keeps every fib(i) up to 200,000. That's about 1.7 GB of big
  integers per iteration, so free RAM and the garbage collector dominate the time.
- It explains the paging seen earlier when only 0.9 GB was free.
- This is faithful to the Pharo original, but be aware of it when comparing.

**B4 — Fannkuch runs only 2 iterations by default.**
- With n=2 the spread and quartiles say almost nothing.
- **Rectify:** run with `harness Fannkuch 5` or more for real comparisons.

**B5 — Mixed runtime versions.**
- Node 18 is end-of-life; Node 22 LTS would be a fairer modern comparison.
- Ruby ran without YJIT; `ruby --yjit` is standard in 3.3 and would be the
  like-for-like with Python 3.15 and the JIT languages.

## 5. What to rectify, in priority order

1. **Sync `01_harness` with the fixed translations** (H1). This is the only
   issue that gives a wrong result.
2. **Validate arguments in every harness**: require iterations ≥ 1 and a
   positive integer, and exit 1 otherwise (M2, M3). JS currently reports
   success on garbage input.
3. **Fix quartiles for n < 2** (M1).
4. **Add a warm-up phase and run the suite several times** before quoting
   numbers (B1, B2, B4).
5. Optional:
   - add self-checks to Fibonacci and StressGC (L1)
   - use the formula for ResilientBlocks verification (L2)
   - add explicit iteration counts to Python Fibonacci (L4)
   - upgrade Node and enable YJIT (B5)

## 6. Fixes applied (2026-11-03)

The code before these fixes is backed up in `backup_before_rerun_fixes/`
(all four translation folders plus `01_harness`).

| Issue | What changed | Files (same change in each language) |
|---|---|---|
| H1 | `01_harness` now matches the fixed translations. Java has the full fixed set, including `BeIntMap.java` and `BeLargeInteger.java`; Python, JS and Ruby have their `run` / `harness` / `benchmark` / `be_random` files. Java Fannkuch now passes there. | `F:\01_Harness_Infrastructure\01_harness\*` |
| M1 | With fewer than 2 runs, Q1 = median = Q3 (no more 0). | `Run.java`, `run.py`, `run.js`, `run.rb` (`quartiles`) |
| M2, M3 | Iteration arguments must be whole numbers ≥ 1. Otherwise the harness prints `Error: num-iterations must be a whole number >= 1, got '…'` plus the usage text, and exits 1. This replaces the crash, the `NaN` output and Ruby's silent 0. | `Harness.java`, `harness.py`, `harness.js`, `harness.rb` |
| L1 | MemoizedFibonacci checks `fib(200000) mod 1000000007 == 216653165`. StressGC checks `chopCount == 9901` at the default 10,000 iterations; other counts aren't checked. A mismatch prints a message and fails the run. | `*MemoizedFibonacci*`, `*StressGC*` |
| L2 | ResilientBlocks checks `n(n-1)/2`, so any inner count can be verified. | `*ResilientBlocks*` |
| L3 | A missing CSV now gives `Cannot read mnist_test.csv. Run DataFrame from the folder that contains mnist_test.csv.` | `*DataFrame*` |
| L4 | Python Fibonacci sets `MAIN_ITERATIONS = 10` and `INNER_ITERATIONS = 250000` itself. | `be_memoized_fibonacci.py` |

The new checks run once per timed iteration and cost microseconds. The
Fibonacci `mod` runs once, on a number of about 139k bits, in every language.

### Verification of the fixes (all four languages, same output)

```
StressGC 1 100       → n=1 … min: Xus 1stQ: Xus median: Xus 3rdQ: Xus max: Xus  (no more 0)
StressGC 0 1         → Error: num-iterations must be a whole number >= 1, got '0'    exit 1
StressGC abc         → Error: num-iterations must be a whole number >= 1, got 'abc'  exit 1
StressGC -3          → Error: num-iterations must be a whole number >= 1, got '-3'   exit 1
ResilientBlocks 2 100→ passes (was "No verification result for 100 found")
StressGC 2 / MemoizedFibonacci 1 3 → pass with the new self-checks
DataFrame without CSV→ "Cannot read mnist_test.csv. Run DataFrame from the folder …"  exit 1
```

### Full rerun after the fixes: 24 / 24 pass

Logs: `raw_logs_stage5_after_fixes/`. Median µs (stdDev % of mean):

| Benchmark | Java | JavaScript | Python 3.15 | Ruby |
|---|---|---|---|---|
| MemoizedFibonacci | **1,110,012** (38%) | 1,661,595 (12%) | 1,245,198 (5%) | 2,048,313 (13%) |
| Fannkuch | **260,106** (10%) | 318,165 (0.1%) | 5,032,276 (0.5%) ‡ | 11,810,711 (1%) |
| MatrixInversion | 3,090 (37%) | **1,640** (122%) | 51,554 (22%) | 57,977 (5%) |
| ResilientBlocks | **12,675** (21%) | 19,966 (12%) | 391,962 (20%) | 681,329 (20%) |
| StressGC | **12,518** (61%) | 19,363 (28%) | 138,925 (4%) | 141,380 (6%) |
| DataFrame | 19,295 (62%) | **18,772** (30%) | 129,519 (2%) | 545,736 (18%) |

‡ In the full run, Python Fannkuch's second iteration took 920 s. The Windows
System log shows the laptop **entered Modern Standby at 11:07:02 and resumed at
11:22:15**, a 913 s pause that matches the extra time. This was an environment
interruption, not a code bug (the first iteration took a normal 6.86 s). The
number above comes from a standalone rerun (`python_Fannkuch_rerun.txt`, 0.5% spread).

The run also confirms B2: medians for unchanged code moved by 10–30% between
runs (for example Java Fibonacci went from 855 ms to 1,110 ms, Ruby
ResilientBlocks from 541 ms to 681 ms). On top of the "Best performance" power
mode, **turn off sleep** (Settings → System → Power → Screen and sleep → Never,
while plugged in) before long runs.
