public class EqProbe { public static void main(String[] a) throws Exception {
  BeMatrix src = BeMatrix.from(new BeRandom().makeInvertable(10)); BeMatrix inv = src.invert();
  double s = 0; for (int i=1;i<=10;i++) for (int j=1;j<=10;j++) s += inv.at(i,j);
  System.out.println("java       invSum=" + String.format("%.17g", s) + " identity=" + inv.multiply(src).isIdentityMatrix());
  BeMemoizedFibonacci f = new BeMemoizedFibonacci();
  System.out.println("java       fib200000 mod 1e9+7=" + f.fibMemo(200000).mod(1000000007) + " fib10=" + f.fibMemo(10).mod(1000000007));
} }
