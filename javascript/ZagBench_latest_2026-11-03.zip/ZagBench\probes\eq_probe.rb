Dir.chdir(ARGV[0]); %w[be_random be_matrix be_memoized_fibonacci be_data_frame].each { |f| require File.join(ARGV[0], f) }
src = BeMatrix.with_data(BeRandom.new.make_invertable(10)); inv = src.invert
s = 0.0; (1..10).each { |i| (1..10).each { |j| s += inv.at(i, j) } }
puts "ruby       invSum=#{'%.17g' % s} identity=#{inv.multiply(src).identity_matrix?}"
f = BeMemoizedFibonacci.new; puts "ruby       fib200000 mod 1e9+7=#{f.fib_memo(200000) % 1000000007} fib10=#{f.fib_memo(10)}"
d = BeDataFrame.new; ok = d.inner_benchmark_loop(500); rows = d.instance_variable_get(:@rows)
puts "ruby       df ok=#{ok} cols=#{d.num_columns} rows=#{d.num_rows} cellSum=#{rows.sum { |r| r.sum(&:to_i) }}"
