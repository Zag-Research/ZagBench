const { BeStressGC } = require(process.argv[2] + '/be_stress_gc');
const b = new BeStressGC(); const c = b._benchmark(10000);
console.log(`javascript chop=${c} tree=${b._tree.allNodes().length} rand=${b._random._rand}`);
