process.chdir(process.argv[2]); const d0 = process.argv[2];
const { BeRandom } = require(d0 + '/be_random'), { BeMatrix } = require(d0 + '/be_matrix');
const { BeMemoizedFibonacci } = require(d0 + '/be_memoized_fibonacci'), { BeDataFrame } = require(d0 + '/be_data_frame');
const src = BeMatrix.withData(new BeRandom().makeInvertable(10)), inv = src.invert();
let s = 0; for (let i = 1; i <= 10; i++) for (let j = 1; j <= 10; j++) s += inv.at(i, j);
console.log(`javascript invSum=${s.toPrecision(17)} identity=${inv.multiply(src).isIdentityMatrix()}`);
const f = new BeMemoizedFibonacci(); console.log(`javascript fib200000 mod 1e9+7=${f.fibMemo(200000) % 1000000007n} fib10=${f.fibMemo(10)}`);
const d = new BeDataFrame(); const ok = d.innerBenchmarkLoop(500); let c = 0; for (const r of d._rows) for (const x of r) c += parseInt(x, 10);
console.log(`javascript df ok=${ok} cols=${d.numberOfColumns} rows=${d.numberOfRows} cellSum=${c}`);
