import sys; sys.path.insert(0, sys.argv[1])
from be_stress_gc import BeStressGC
b = BeStressGC(); c = b._benchmark(10000)
print("python chop=%d tree=%d rand=%d" % (c, len(b._tree.all_nodes()), b._random._rand))
