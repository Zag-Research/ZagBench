public class GcProbe { public static void main(String[] a) throws Exception {
  BeStressGC b = new BeStressGC();
  java.lang.reflect.Method m = BeStressGC.class.getDeclaredMethod("benchmark", int.class); m.setAccessible(true);
  int c = (int) m.invoke(b, 10000);
  java.lang.reflect.Field tf = BeStressGC.class.getDeclaredField("tree"); tf.setAccessible(true);
  java.lang.reflect.Field rf = BeStressGC.class.getDeclaredField("random"); rf.setAccessible(true);
  java.lang.reflect.Field sf = BeRandom.class.getDeclaredField("rand"); sf.setAccessible(true);
  System.out.println("java chop=" + c + " tree=" + ((BeRandomTreeNode) tf.get(b)).allNodes().length + " rand=" + sf.get(rf.get(b)));
} }
