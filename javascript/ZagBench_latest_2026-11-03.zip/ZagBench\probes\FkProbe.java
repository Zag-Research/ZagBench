public class FkProbe { public static void main(String[] a) throws Exception {
  BeFannkuch f = new BeFannkuch(); java.lang.reflect.Method m = BeFannkuch.class.getDeclaredMethod("solve", int.class); m.setAccessible(true);
  for (int n=1;n<=10;n++){ int[] r=(int[])m.invoke(f,n); System.out.println("n="+n+" checksum="+r[0]+" maxFlips="+r[1]); } } }
